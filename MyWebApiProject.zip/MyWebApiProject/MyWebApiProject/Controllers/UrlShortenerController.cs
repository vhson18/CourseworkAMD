﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using UrlShortenerApi.Services;

namespace UrlShortenerApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UrlShortenerController : ControllerBase
    {
        private readonly UrlShortenerService _service;

        public UrlShortenerController(UrlShortenerService service)
        {
            _service = service;
        }

        [HttpPost("shorten")]
        public async Task<IActionResult> ShortenUrl([FromBody] string originalUrl)
        {
            var shortUrl = await _service.ShortenUrlAsync(originalUrl);
            return Ok(new { shortUrl });
        }

        [HttpGet("{shortUrl}")]
        public async Task<IActionResult> RedirectToOriginalUrl(string shortUrl)
        {
            var originalUrl = await _service.GetOriginalUrlAsync(shortUrl);
            if (string.IsNullOrEmpty(originalUrl))
            {
                // Log the issue
                Console.WriteLine($"Original URL not found for short URL: {shortUrl}");
                return NotFound();
            }

            // Validate the original URL
            if (!Uri.TryCreate(originalUrl, UriKind.Absolute, out _))
            {
                // Log the issue
                Console.WriteLine($"Invalid original URL: {originalUrl}");
                return BadRequest("Invalid original URL");
            }

            // Log the successful redirect
            Console.WriteLine($"Redirecting short URL: {shortUrl} to original URL: {originalUrl}");
            return RedirectPermanent(originalUrl);
        }

    }
}