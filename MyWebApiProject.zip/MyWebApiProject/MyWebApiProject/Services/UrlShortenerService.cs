﻿using MongoDB.Driver;
using System;
using System.Threading.Tasks;
using UrlShortenerApi.Data;
using UrlShortenerApi.Models;

namespace UrlShortenerApi.Services
{
    public class UrlShortenerService
    {
        private readonly UrlShortenerContext _context;

        public UrlShortenerService(UrlShortenerContext context)
        {
            _context = context;
        }

        public async Task<string> ShortenUrlAsync(string originalUrl)
        {
            var shortUrl = Guid.NewGuid().ToString().Substring(0, 6);

            var urlMapping = new UrlMapping
            {
                ShortUrl = shortUrl,
                OriginalUrl = originalUrl
            };

            await _context.UrlMappings.InsertOneAsync(urlMapping);

            return shortUrl;
        }

        public async Task<string> GetOriginalUrlAsync(string shortUrl)
        {
            var filter = Builders<UrlMapping>.Filter.Eq("ShortUrl", shortUrl);
            var urlMapping = await _context.UrlMappings.Find(filter).FirstOrDefaultAsync();

            return urlMapping?.OriginalUrl;
        }
    }
}
